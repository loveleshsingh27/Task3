package com.sis.bean;

import java.util.Scanner;

public class StudentBean {
    private int sNo;
    private String enrollNo;
    private String name;
    private String email;
    private int phyMarks;
    private int chemMarks;
    private int mathsMarks;
    private int engMarks;
    private int hindiMarks;
    private float per;
    private String status;

    public StudentBean() {
    }

    public StudentBean(int sNo, String enrollNo, String name, String email, int phyMarks, int chemMarks, int mathsMarks, int engMarks, int hindiMarks, float per, String status) {
        this.sNo = sNo;
        this.enrollNo = enrollNo;
        this.name = name;
        this.email = email;
        this.phyMarks = phyMarks;
        this.chemMarks = chemMarks;
        this.mathsMarks = mathsMarks;
        this.engMarks = engMarks;
        this.hindiMarks = hindiMarks;
        this.per = per;
        this.status = status;
    }

    public int getsNo() {
        return sNo;
    }

    public void setsNo(int sNo) {
        this.sNo = sNo;
    }

    public String getEnrollNo() {
        return enrollNo;
    }

    public void setEnrollNo(String enrollNo) {
        this.enrollNo = enrollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPhyMarks() {
        return phyMarks;
    }

    public void setPhyMarks(int phyMarks) {
        this.phyMarks = phyMarks;
    }

    public int getChemMarks() {
        return chemMarks;
    }

    public void setChemMarks(int chemMarks) {
        this.chemMarks = chemMarks;
    }

    public int getMathsMarks() {
        return mathsMarks;
    }

    public void setMathsMarks(int mathsMarks) {
        this.mathsMarks = mathsMarks;
    }

    public int getEngMarks() {
        return engMarks;
    }

    public void setEngMarks(int engMarks) {
        this.engMarks = engMarks;
    }

    public int getHindiMarks() {
        return hindiMarks;
    }

    public void setHindiMarks(int hindiMarks) {
        this.hindiMarks = hindiMarks;
    }

    public float getPer() {
        return per;
    }

    public void setPer(float per) {
        this.per = per;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public void getData() {
        Scanner sk = new Scanner(System.in);
        
        System.out.print("SERIAL NO: ");
        sNo = sk.nextInt();
        sk.nextLine();
        System.out.print("ENROLLMENT NO: ");
        enrollNo = sk.nextLine();
        System.out.print("NAME: ");
        name = sk.nextLine();
        System.out.print("EMAIL: ");
        email = sk.nextLine();
        System.out.print("PHYSICS MARKS: ");
        phyMarks = sk.nextInt();
        System.out.print("CHEMISTRY MARKS: ");
        chemMarks = sk.nextInt();
        System.out.print("MATHS MARKS: ");
        mathsMarks = sk.nextInt();
        System.out.print("ENGLISH MARKS: ");
        engMarks = sk.nextInt();
        System.out.print("HINDI MARKS: ");
        hindiMarks = sk.nextInt();
        
        per = (phyMarks + chemMarks + mathsMarks + engMarks + hindiMarks)/5.0f;
        
        if(phyMarks >= 30 && chemMarks >= 30 && mathsMarks >= 30 && engMarks >= 30 && hindiMarks >= 30) {
            status = "PASS";
        } else {
            status = "FAIL";
        }
    }
}