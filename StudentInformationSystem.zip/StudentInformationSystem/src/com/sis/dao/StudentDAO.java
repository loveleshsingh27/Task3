package com.sis.dao;

import com.sis.bean.StudentBean;
import com.sis.utility.ConnectionPool;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StudentDAO {
    static Connection con;
    
    public int AddStudent(StudentBean sb) {
        int result = 0 ;
        
        con = ConnectionPool.connectDB();
        String sql = "insert into student values ('"+sb.getsNo()+"', '"+sb.getEnrollNo()+"', '"+sb.getName()+"', '"+sb.getEmail()+"', '"+sb.getPhyMarks()+"', '"+sb.getChemMarks()+"', '"+sb.getMathsMarks()+"', '"+sb.getEngMarks()+"', '"+sb.getHindiMarks()+"', '"+sb.getPer()+"', '"+sb.getStatus()+"')";
        try {
            Statement stmt = con.createStatement();
            result = stmt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
    public int UpdateStudent(StudentBean sb) {
        int result = 0 ;
        
        con = ConnectionPool.connectDB();
        String sql = "update student set ENROLLMENT_NO = '"+sb.getEnrollNo()+"', NAME = '"+sb.getName()+"', EMAIL = '"+sb.getEmail()+"', PHYSICS_MARKS = '"+sb.getPhyMarks()+"', CHEMISTRY_MARKS = '"+sb.getChemMarks()+"', MATHS_MARKS = '"+sb.getMathsMarks()+"', ENGLISH_MARKS = '"+sb.getEngMarks()+"', HINDI_MARKS = '"+sb.getHindiMarks()+"', PERCENTAGE = '"+sb.getPer()+"', STATUS = '"+sb.getStatus()+"' where S_NO = '"+sb.getsNo()+"'";
        try {
            Statement stmt = con.createStatement();
            result = stmt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
    public int DeleteStudent(int sNo) {
        int result = 0 ;
        
        con = ConnectionPool.connectDB();
        String sql = "delete from student where S_NO = '"+sNo+"'";
        try {
            Statement stmt = con.createStatement();
            result = stmt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
    public ArrayList<StudentBean> FindAllStudent() {
        con = ConnectionPool.connectDB();
        String sql = "select * from student";
        ArrayList<StudentBean> al = new ArrayList<StudentBean>();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                StudentBean sb = new StudentBean();
                sb.setsNo(rs.getInt("S_NO"));
                sb.setEnrollNo(rs.getString("ENROLLMENT_NO"));
                sb.setName(rs.getString("NAME"));
                sb.setEmail(rs.getString("EMAIL"));
                sb.setPhyMarks(rs.getInt("PHYSICS_MARKS"));
                sb.setChemMarks(rs.getInt("CHEMISTRY_MARKS"));
                sb.setMathsMarks(rs.getInt("MATHS_MARKS"));
                sb.setEngMarks(rs.getInt("ENGLISH_MARKS"));
                sb.setHindiMarks(rs.getInt("HINDI_MARKS"));
                sb.setPer(rs.getFloat("PERCENTAGE"));
                sb.setStatus(rs.getString("STATUS"));
                al.add(sb);
            }
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }
    
    public ArrayList<StudentBean> FindBySNo(int sNo) {
        con = ConnectionPool.connectDB();
        String sql = "select * from student where S_NO = '"+sNo+"'";
        ArrayList<StudentBean> al = new ArrayList<StudentBean>();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                StudentBean sb = new StudentBean();
                sb.setsNo(rs.getInt("S_NO"));
                sb.setEnrollNo(rs.getString("ENROLLMENT_NO"));
                sb.setName(rs.getString("NAME"));
                sb.setEmail(rs.getString("EMAIL"));
                sb.setPhyMarks(rs.getInt("PHYSICS_MARKS"));
                sb.setChemMarks(rs.getInt("CHEMISTRY_MARKS"));
                sb.setMathsMarks(rs.getInt("MATHS_MARKS"));
                sb.setEngMarks(rs.getInt("ENGLISH_MARKS"));
                sb.setHindiMarks(rs.getInt("HINDI_MARKS"));
                sb.setPer(rs.getFloat("PERCENTAGE"));
                sb.setStatus(rs.getString("STATUS"));
                al.add(sb);
            }
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }
    
    public ArrayList<StudentBean> FindByEnrollNo(String enrollNo) {
        con = ConnectionPool.connectDB();
        String sql = "select * from student where ENROLLMENT_NO = '"+enrollNo+"'";
        ArrayList<StudentBean> al = new ArrayList<StudentBean>();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                StudentBean sb = new StudentBean();
                sb.setsNo(rs.getInt("S_NO"));
                sb.setEnrollNo(rs.getString("ENROLLMENT_NO"));
                sb.setName(rs.getString("NAME"));
                sb.setEmail(rs.getString("EMAIL"));
                sb.setPhyMarks(rs.getInt("PHYSICS_MARKS"));
                sb.setChemMarks(rs.getInt("CHEMISTRY_MARKS"));
                sb.setMathsMarks(rs.getInt("MATHS_MARKS"));
                sb.setEngMarks(rs.getInt("ENGLISH_MARKS"));
                sb.setHindiMarks(rs.getInt("HINDI_MARKS"));
                sb.setPer(rs.getFloat("PERCENTAGE"));
                sb.setStatus(rs.getString("STATUS"));
                al.add(sb);
            }
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }
    
    public static void main(String[] args) {
        StudentDAO sd = new StudentDAO();
        StudentBean s = new StudentBean();
        
        s.getData();
        
        int sNo = s.getsNo();
        String enrollNo = s.getEnrollNo();
        String name = s.getName();
        String email = s.getEmail();
        int phyMarks = s.getPhyMarks();
        int chemMarks = s.getChemMarks();
        int mathsMarks = s.getMathsMarks();
        int engMarks = s.getEngMarks();
        int hindiMarks = s.getHindiMarks();
        float per = s.getPer();
        String status = s.getStatus();
        
        s.setsNo(sNo);
        s.setEnrollNo(enrollNo);
        s.setName(name);
        s.setEmail(email);
        s.setPhyMarks(phyMarks);
        s.setChemMarks(chemMarks);
        s.setMathsMarks(mathsMarks);
        s.setEngMarks(engMarks);
        s.setHindiMarks(hindiMarks);
        s.setPer(per);
        s.setStatus(status);
        
//        int x = sd.AddStudent(s);
//        if(x>0) {
//            System.out.println("Data Insert Success");
//        } else {
//            System.out.println("Data Insert Fail");
//        }
        
//        int x = sd.UpdateStudent(s);
//        if(x>0) {
//            System.out.println("Data Update Success");
//        } else {
//            System.out.println("Data Update Fail");
//        }
        
//        int x = sd.DeleteStudent(sNo);
//        if(x>0) {
//            System.out.println("Data Delete Success");
//        } else {
//            System.out.println("Data Delete Fail");
//        }

//        sd.FindAllStudent();
        
//        sd.FindBySNo(sNo);
        
//        sd.FindByEnrollNo(enrollNo);
    }
}

